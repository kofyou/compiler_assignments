#include "node.h"
#include <iostream>
using namespace std;

bool Inside(uint8_t x, uint8_t l, uint8_t h) {
    if (l < h) {
		return x > l && x < h; 
	} else if (h == 0) {
		return Inside(x, l, 8);
	} else {
		return x == 0 || Inside(x, l, 8) || Inside(x, 0, h);
	}
}

int main() {
    Node n0(0), n1(30), n2(65), n3(110), n4(160), n5(230);
    n0.join(NULL);
    n1.join(&n0);
	n2.join(&n1);
	n3.join(&n2);
	n4.join(&n3);
	n5.join(&n4);
	n0.printFingerTable();
	n1.printFingerTable();
	n2.printFingerTable();
	n3.printFingerTable();
	n4.printFingerTable();
	n5.printFingerTable();
	printf("=========\n\n");
	n0.insert(3,3);
	n1.insert(200);
	n2.insert(123);
	n3.insert(45,3);
	n4.insert(99);
	n2.insert(60,10);
	n0.insert(50,8);
	n3.insert(100,5);
	n3.insert(101,4);
	n3.insert(102,6);
	n5.insert(240,8);
	n5.insert(250,10);
	printf("=========\n\n");
	n0.printKeys();
	n1.printKeys();
	n2.printKeys();
	n3.printKeys();
	n4.printKeys();
	n5.printKeys();
	printf("=========\n\n");
	Node n6(100);
	n6.join(&n2);

    return 0;
}