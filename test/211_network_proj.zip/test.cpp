#include "node.h"
#include <iostream>
using namespace std;

int main() {
    uint8_t x, l, h;
    scanf("%hhd%hhd%hhd",&x, &l, &h);
    printf("%hhd, %hhd, %hhd, %d\n", x, l, h, isInside(x, l, h));
    return 0;
}