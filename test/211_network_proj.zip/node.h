// Reference: 
#ifndef NODE_H
#define NODE_H

#include <stdint.h>
#include <map>
#include <set>
#include <vector>
#include <cmath>
#include <cstdio>

#define BITLENGTH 8
#define POW(x) uint8_t(pow(2, x))
#define BASE 256

// if x belongs to (l, h)
bool isInside(uint8_t x, uint16_t l, uint16_t h) {
	if (l < h) {
		return x > l && x < h;
	} else if (h == 0) {
		return isInside(x, l, BASE);
	} else {
		return x == 0 || isInside(x, l, BASE) || isInside(x, 0, h);
	}
}

// forward declaration
class Node;

// The following code is just for reference. You can define your own finger table class.
// Since the index uniquely determines the interval, only the successor needs to be maintained.  
class FingerTable{
public:
	/**
	 * @param nodeId: the id of node hosting the finger table.
	 */
	FingerTable(uint8_t nodeId);
	void set(size_t index, Node* successor){
		fingerTable_[index] = successor;
	}
	Node* get(size_t index) {
		return fingerTable_[index];
	}
	// TODO: complete print function
	void prettyPrint();
private:
	uint8_t nodeId_;
	std::vector<Node*> fingerTable_;
};

FingerTable::FingerTable(uint8_t nodeId): nodeId_(nodeId) {
	// According to Chord paper, the finger table starts from index=1
	fingerTable_.resize(BITLENGTH + 1);
}

class Node {
public:
	Node(uint8_t id): id_(id), fingerTable_(id) {}
	// TODO: implement node join function
	/**
	 * @param node: the first node to contact with to initialize join process. If this is the first node to join the Chord network, the parameter is NULL.
	 */
	void join(Node* node) {
		if (node != NULL) {
			initFingerTable(node);
			if(node->getId() != 0) {
			updateOrthers();
			} else {
				node->setSuccessor(this);
				node->fingerTable_.set(2, this);
				node->fingerTable_.set(3, this);
				node->fingerTable_.set(4, this);
				node->fingerTable_.set(5, this);
				printf("%d: hand update fb of 0:\n",__LINE__);
				node->fingerTable_.prettyPrint();
			}
			moveKeys();
		} else {
			for (size_t i = 1; i <= BITLENGTH; i++) {
				fingerTable_.set(i, this);
			}
			setPredecessor(this);
			printf("%d: %d first join, set all fb self, and set pred self\n",__LINE__, getId());
		}
		fingerTable_.prettyPrint();
	}

	void initFingerTable(Node* node) {
		// first key
		uint8_t key = (getId() + 1) % BASE;
		setSuccessor(node->findSuccessor(key));
		setPredecessor(getSuccessor()->getPredecessor());
		getSuccessor()->setPredecessor(this);
		printf("%d: %d join via %d, set succ: %d, set pred: %d, set succ->pred: %d\n",__LINE__, getId(),
				node->getId(), getSuccessor()->getId(), getPredecessor()->getId(), getSuccessor()->getPredecessor()->getId());
		// getSuccessor()->setSuccessor(this);
		for (size_t i = 1; i < BITLENGTH; i++) {
			// key of the (i+1)th entry
			key = (getId() + POW((i+1) - 1)) % BASE;
			// if (key >= getId() && key < fingerTable_.get(i)->getId()) {
			if(key == getId() || isInside(key, getId(), fingerTable_.get(i)->getId())) {
				fingerTable_.set(i+1, fingerTable_.get(i));
			} else {
				fingerTable_.set(i+1, node->findSuccessor(key));
			}
			printf("%d: init %ldth fb ~ %d to %d\n",__LINE__, i+1, key, fingerTable_.get(i+1)->getId());
		}
	}

	void updateOrthers() {
		printf("%d: auto update other fb:\n",__LINE__);
		for (size_t i = 1; i <= BITLENGTH; i++) {
			// 
			uint8_t key = (getId() - POW(i - 1)) % BASE;
			printf("%d: the %ldth backward key: %d\n",__LINE__, i, key);
			Node *n = findPredecessor(key);
			printf("%d: its pred: %d\n",__LINE__, n->getId());
			n->updateFingerTable(this, i);
		}
	}

	void updateFingerTable(Node* s, size_t i) {
		// if (s->getId() >= getId() && s->getId() < fingerTable_.get(i)->getId()) {
		printf("%d: updateFB(%d, %ldth)\n", __LINE__, s->getId(), i);
		printf("%d: key %d inside [this: %d, this->%ldth f: %d) ? \n",__LINE__, s->getId(), getId(), i, fingerTable_.get(i)->getId());
		if(/*s->getId() == getId() || */isInside(s->getId(), getId(), fingerTable_.get(i)->getId())) {
			fingerTable_.set(i, s);
			printf("%d: yes, recurse pred: %d\n", __LINE__, getPredecessor()->getId());
			getPredecessor()->updateFingerTable(s, i);
		} else {
			printf("%d: no, end %ldth backward update\n", __LINE__, i);
		}
	}

	void moveKeys() {
		printf("start move key\n");
		std::vector<std::pair<uint8_t, uint8_t>> keyList = getSuccessor()->getKeyListAndRemove(getId());
		for (size_t i = 0; i < keyList.size(); i++) {
			printf("migrate key %d from %d to %d\n", keyList[i].first, getSuccessor()->getId(), getId());
			localInsert(keyList[i].first, keyList[i].second);
		}
	}

	std::vector<std::pair<uint8_t, uint8_t>> getKeyListAndRemove(uint8_t id) {
		std::vector<std::pair<uint8_t, uint8_t>> keyList;
		printKeys();
		for (std::map<uint8_t, uint8_t>::iterator it = localKeys_.begin(), next_it = it; it != localKeys_.end(); it = next_it) {
			// if (it->first <= id) { // TODO: check if it is right
			printf("%d: pair: %d, %d\n", __LINE__, it->first, it->second);
			printf("%d: key %d inside (join: %d, this: %d] ? \n",__LINE__, it->first, id, getId());
			++next_it;
			if (!isInside(it->first, id, getId()) && it->first != getId()) {
				printf("%d: no, should remove\n",__LINE__);
				keyList.push_back(*it);
				localRemove(it->first);
			}
		}
		return keyList;
	}

	// TODO: implement DHT lookup
	// Given a key, return the id of the node responsibile for the key,
	// i.e., find the successor of the key.
	uint8_t find(uint8_t key) {
		// TODO: return value
		return findSuccessor(key)->getId();
	}

	Node* findSuccessor(uint8_t key) {
		// TODO: print path
		Node* n = findPredecessor(key);
		return n->getSuccessor();
	}

	// 
	Node* findPredecessor(uint8_t key) {
		Node* n = this;
		// while (key <= n->getId() || key > n->getSuccessor()->getId()) {
		// while (!isInside(key, n->getId(), n->getSuccessor()->getId() && key != n->getSuccessor()->getId())) {
		while (1) {
			printf("%d: ask %d to find pred of %d\n",__LINE__, n->getId(), key);
			printf("%d: key %d inside (this: %d, this->succ: %d] ? \n",__LINE__, key, n->getId(), n->getSuccessor()->getId());
			if (!isInside(key, n->getId(), n->getSuccessor()->getId()) && key != n->getSuccessor()->getId()) {
				printf("%d: no\n", __LINE__);
				n = n->closestPrecedingFinger(key);
				printf("%d: update this to this closet f: %d\n", __LINE__, n->getId());
			} else {
				printf("%d: yes\n", __LINE__);
				break;
			}
		}
		printf("%d: return %d as %d's pred\n", __LINE__, n->getId(), key);
		return n;
	}

	Node* closestPrecedingFinger(uint8_t key) {
		for (size_t i = BITLENGTH; i > 0; i--) {
			Node* fingerNode = fingerTable_.get(i);
			uint8_t fingerNodeId = fingerNode->getId();
			// if (fingerNodeId > getId() && fingerNodeId < key) {
			if (isInside(fingerNodeId, getId(), key)) {
				return fingerNode;
			}
		}
		return this;
	}

	// TODO: implement DHT key insertion
	void insert(uint8_t key, uint8_t value = 0) {
		findSuccessor(key)->localInsert(key, value);
	}

	void localInsert(uint8_t key, uint8_t value = 0) {
		localKeys_[key] = value;
	}

	// TODO: implement DHT key deletion
	void remove(uint8_t key) {
		findSuccessor(key)->localRemove(key);
	}

	void localRemove(uint8_t key) {
		localKeys_.erase(key);
	}

	uint8_t getId() {
		return id_;
	}

	Node* getSuccessor() {
		return fingerTable_.get(1);
	}

	void setSuccessor(Node* node) {
		fingerTable_.set(1, node);
	}

	Node* getPredecessor() {
		return fingerTable_.get(0);
	}

	void setPredecessor(Node* node) {
		fingerTable_.set(0, node);
	}

	void printFingerTable() {
		fingerTable_.prettyPrint();
	}

	void printKeys() {
		printf("%-12s %d\n", "nodeId:", getId());
		printf("=====================================================\n");
		for (std::map<uint8_t, uint8_t>::iterator it = localKeys_.begin(); it != localKeys_.end(); it++) {
			printf("%d: %d\n", it->first, it->second);
		}
		printf("\n");
	}
	FingerTable fingerTable_;
private:
	uint8_t id_;

	std::map<uint8_t, uint8_t> localKeys_;
};

void FingerTable::prettyPrint() {
	printf("%-12s %d\n", "nodeId:", nodeId_);
	printf("%-12s %d\n", "predecessor:", get(0)->getId());
	printf("%-12s %d\n", "successor:", get(1)->getId());
	printf("=====================================================\n");
	printf("%-5s%-12s%-10s\n", "NO.", "interval", "finger");
	for(size_t i = 1; i < fingerTable_.size(); i++) {
		char buffer[100];
		sprintf(buffer, "[%d, %d)",(nodeId_ + POW(i - 1)) % BASE, (nodeId_ + POW((i+1) - 1)) % BASE);
		printf("%-5ld%-12s%-10d\n", i, buffer, get(i)->getId());
	}
	printf("\n");
}
#endif
